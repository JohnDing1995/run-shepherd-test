#from gettext import gettext as _
gettext = lambda t: t
_ = gettext
